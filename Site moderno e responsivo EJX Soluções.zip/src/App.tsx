import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import WhatsAppButton from './components/WhatsAppButton'
import Home from './pages/Home'
import Servicos from './pages/Servicos'
import ServicoDetalhes from './pages/ServicoDetalhes'
import Loja from './pages/Loja'
import Orcamento from './pages/Orcamento'
import QuemSomos from './pages/QuemSomos'
import Contato from './pages/Contato'
import Blog from './pages/Blog'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/servicos" element={<Servicos />} />
            <Route path="/servicos/:slug" element={<ServicoDetalhes />} />
            <Route path="/loja" element={<Loja />} />
            <Route path="/orcamento" element={<Orcamento />} />
            <Route path="/quem-somos" element={<QuemSomos />} />
            <Route path="/contato" element={<Contato />} />
            <Route path="/blog" element={<Blog />} />
          </Routes>
        </main>
        <Footer />
        <WhatsAppButton />
        <Toaster position="top-right" />
      </div>
    </Router>
  )
}

export default App