import React from 'react'
import { Link } from 'react-router-dom'
import {Settings, Zap, Droplets, Wrench, Home as HomeIcon, Hammer} from 'lucide-react'

const Servicos = () => {
  const services = [
    {
      id: 'automacao-residencial',
      icon: <Settings className="h-16 w-16 text-ejx-orange" />,
      title: "Automação Residencial",
      description: "Transforme sua casa em um ambiente inteligente com sistemas de automação modernos. Controle iluminação, temperatura, segurança e muito mais.",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
      features: ["Controle de iluminação", "Sistemas de segurança", "Climatização inteligente", "Integração com assistentes virtuais"]
    },
    {
      id: 'eletrica',
      icon: <Zap className="h-16 w-16 text-ejx-orange" />,
      title: "Serviços Elétricos",
      description: "Instalações, manutenções e reparos elétricos com total segurança e qualidade. Profissionais certificados e materiais de primeira linha.",
      image: "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
      features: ["Instalações elétricas", "Manutenção preventiva", "Quadros elétricos", "Iluminação LED"]
    },
    {
      id: 'hidraulica',
      icon: <Droplets className="h-16 w-16 text-ejx-orange" />,
      title: "Serviços Hidráulicos",
      description: "Soluções completas em hidráulica, desde pequenos vazamentos até instalações completas. Atendimento rápido e eficiente.",
      image: "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
      features: ["Reparos de vazamentos", "Instalação de tubulações", "Desentupimentos", "Manutenção de torneiras"]
    },
    {
      id: 'pequenos-reparos',
      icon: <Wrench className="h-16 w-16 text-ejx-orange" />,
      title: "Pequenos Reparos",
      description: "Aqueles pequenos problemas que incomodam no dia a dia. Nossa equipe resolve com agilidade e preço justo.",
      image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
      features: ["Furos em paredes", "Troca de fechaduras", "Montagem de móveis", "Reparos diversos"]
    },
    {
      id: 'gesso',
      icon: <HomeIcon className="h-16 w-16 text-ejx-orange" />,
      title: "Gesso e Acabamentos",
      description: "Trabalhos em gesso, divisórias, forros e acabamentos que deixam seu ambiente mais bonito e funcional.",
      image: "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
      features: ["Forros de gesso", "Divisórias", "Sancas", "Acabamentos decorativos"]
    },
    {
      id: 'pisos',
      icon: <Hammer className="h-16 w-16 text-ejx-orange" />,
      title: "Pisos e Revestimentos",
      description: "Instalação e manutenção de pisos diversos. Renovação de ambientes com qualidade e durabilidade.",
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
      features: ["Pisos laminados", "Cerâmicas", "Porcelanatos", "Reparos em pisos"]
    }
  ]

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-ejx-blue mb-6">
            Nossos Serviços
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Oferecemos soluções completas para sua residência ou empresa. 
            Conheça todos os nossos serviços e descubra como podemos ajudar você.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div key={service.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-ejx-blue bg-opacity-20"></div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center mb-4">
                  {service.icon}
                  <h3 className="text-xl font-bold text-ejx-blue ml-3">{service.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-4">{service.description}</p>
                
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <div className="w-2 h-2 bg-ejx-orange rounded-full mr-2"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <div className="flex space-x-3">
                  <Link
                    to={`/servicos/${service.id}`}
                    className="flex-1 bg-ejx-blue hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-center font-semibold transition-colors"
                  >
                    Saiba Mais
                  </Link>
                  <Link
                    to="/orcamento"
                    className="flex-1 bg-ejx-orange hover:bg-orange-600 text-white px-4 py-2 rounded-lg text-center font-semibold transition-colors"
                  >
                    Orçamento
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20 bg-ejx-gray rounded-lg p-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-ejx-blue mb-4">
            Não encontrou o que procura?
          </h2>
          <p className="text-gray-600 mb-6">
            Entre em contato conosco! Temos soluções personalizadas para suas necessidades.
          </p>
          <Link
            to="/contato"
            className="inline-block bg-ejx-orange hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
          >
            Falar Conosco
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Servicos