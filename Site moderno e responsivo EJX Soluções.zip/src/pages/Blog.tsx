import React, { useState } from 'react'
import {Calendar, User, Tag, Search, ArrowRight} from 'lucide-react'
import { Link } from 'react-router-dom'

interface BlogPost {
  id: number
  title: string
  excerpt: string
  content: string
  author: string
  date: string
  category: string
  image: string
  tags: string[]
}

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState('todos')
  const [searchTerm, setSearchTerm] = useState('')

  const blogPosts: BlogPost[] = [
    {
      id: 1,
      title: "5 Dicas Essenciais para Manutenção Elétrica Preventiva",
      excerpt: "Aprenda como evitar problemas elétricos em casa com manutenção preventiva simples e eficaz.",
      content: "A manutenção elétrica preventiva é fundamental para garantir a segurança...",
      author: "Eduardo Silva",
      date: "2024-01-15",
      category: "eletrica",
      image: "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
      tags: ["manutenção", "segurança", "elétrica"]
    },
    {
      id: 2,
      title: "Automação Residencial: Por Onde Começar?",
      excerpt: "Guia completo para quem quer dar os primeiros passos na automação da sua casa.",
      content: "A automação residencial não precisa ser complicada ou cara...",
      author: "João Santos",
      date: "2024-01-12",
      category: "automacao",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
      tags: ["automação", "casa inteligente", "tecnologia"]
    },
    {
      id: 3,
      title: "Como Identificar e Resolver Vazamentos Pequenos",
      excerpt: "Dicas práticas para detectar e solucionar vazamentos antes que se tornem um grande problema.",
      content: "Vazamentos pequenos podem causar grandes prejuízos se não forem tratados...",
      author: "Carlos Oliveira",
      date: "2024-01-10",
      category: "hidraulica",
      image: "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
      tags: ["hidráulica", "vazamentos", "economia"]
    },
    {
      id: 4,
      title: "Iluminação LED: Vantagens e Como Escolher",
      excerpt: "Descubra os benefícios da iluminação LED e aprenda a escolher a melhor opção para cada ambiente.",
      content: "A iluminação LED revolucionou o mercado de iluminação...",
      author: "Eduardo Silva",
      date: "2024-01-08",
      category: "eletrica",
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
      tags: ["LED", "economia", "sustentabilidade"]
    },
    {
      id: 5,
      title: "Pequenos Reparos que Você Pode Fazer em Casa",
      excerpt: "Lista de reparos simples que qualquer pessoa pode fazer com as ferramentas certas.",
      content: "Nem todo reparo precisa de um profissional...",
      author: "Ana Costa",
      date: "2024-01-05",
      category: "reparos",
      image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
      tags: ["DIY", "ferramentas", "economia"]
    },
    {
      id: 6,
      title: "Sistemas de Segurança Inteligentes: Vale a Pena?",
      excerpt: "Análise completa dos sistemas de segurança residencial inteligentes e seus benefícios.",
      content: "A segurança residencial evoluiu muito com a tecnologia...",
      author: "João Santos",
      date: "2024-01-03",
      category: "automacao",
      image: "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
      tags: ["segurança", "automação", "monitoramento"]
    }
  ]

  const categories = [
    { id: 'todos', name: 'Todos os Posts', count: blogPosts.length },
    { id: 'automacao', name: 'Automação', count: blogPosts.filter(p => p.category === 'automacao').length },
    { id: 'eletrica', name: 'Elétrica', count: blogPosts.filter(p => p.category === 'eletrica').length },
    { id: 'hidraulica', name: 'Hidráulica', count: blogPosts.filter(p => p.category === 'hidraulica').length },
    { id: 'reparos', name: 'Reparos', count: blogPosts.filter(p => p.category === 'reparos').length }
  ]

  const filteredPosts = blogPosts.filter(post => {
    const matchesCategory = selectedCategory === 'todos' || post.category === selectedCategory
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    })
  }

  const featuredPost = blogPosts[0]

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-ejx-blue mb-6">
            Blog EJX Soluções
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Dicas, tutoriais e novidades sobre automação residencial, manutenção e cuidados domésticos
          </p>
        </div>

        {/* Post em Destaque */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative h-64 lg:h-auto">
              <img
                src={featuredPost.image}
                alt={featuredPost.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 left-4">
                <span className="bg-ejx-orange text-white px-3 py-1 rounded-full text-sm font-semibold">
                  Destaque
                </span>
              </div>
            </div>
            <div className="p-8 flex flex-col justify-center">
              <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1" />
                  {formatDate(featuredPost.date)}
                </div>
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  {featuredPost.author}
                </div>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-ejx-blue mb-4">
                {featuredPost.title}
              </h2>
              <p className="text-gray-600 mb-6 text-lg">
                {featuredPost.excerpt}
              </p>
              <div className="flex flex-wrap gap-2 mb-6">
                {featuredPost.tags.map(tag => (
                  <span
                    key={tag}
                    className="bg-ejx-gray text-ejx-blue px-3 py-1 rounded-full text-sm"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
              <button className="bg-ejx-orange hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors inline-flex items-center">
                Ler Artigo Completo
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-8">
            {/* Busca */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-lg font-bold text-ejx-blue mb-4">Buscar Posts</h3>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Digite sua busca..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                />
              </div>
            </div>

            {/* Categorias */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-lg font-bold text-ejx-blue mb-4">Categorias</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors flex justify-between items-center ${
                      selectedCategory === category.id
                        ? 'bg-ejx-orange text-white'
                        : 'hover:bg-ejx-gray text-gray-600'
                    }`}
                  >
                    <span>{category.name}</span>
                    <span className={`text-sm ${
                      selectedCategory === category.id ? 'text-white' : 'text-gray-400'
                    }`}>
                      {category.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Tags Populares */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-lg font-bold text-ejx-blue mb-4">Tags Populares</h3>
              <div className="flex flex-wrap gap-2">
                {['automação', 'elétrica', 'hidráulica', 'segurança', 'economia', 'DIY', 'LED', 'manutenção'].map(tag => (
                  <button
                    key={tag}
                    onClick={() => setSearchTerm(tag)}
                    className="bg-ejx-gray hover:bg-ejx-orange hover:text-white text-ejx-blue px-3 py-1 rounded-full text-sm transition-colors"
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Newsletter */}
            <div className="bg-ejx-blue text-white rounded-lg p-6">
              <h3 className="text-lg font-bold mb-4">Newsletter</h3>
              <p className="text-gray-200 text-sm mb-4">
                Receba dicas e novidades diretamente no seu e-mail
              </p>
              <div className="space-y-3">
                <input
                  type="email"
                  placeholder="Seu e-mail"
                  className="w-full px-3 py-2 rounded-lg text-gray-800"
                />
                <button className="w-full bg-ejx-orange hover:bg-orange-600 text-white py-2 rounded-lg font-semibold transition-colors">
                  Inscrever-se
                </button>
              </div>
            </div>
          </div>

          {/* Posts Grid */}
          <div className="lg:col-span-3">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-2xl font-bold text-ejx-blue">
                {selectedCategory === 'todos' ? 'Todos os Posts' : categories.find(c => c.id === selectedCategory)?.name}
              </h2>
              <span className="text-gray-500">
                {filteredPosts.length} {filteredPosts.length === 1 ? 'post encontrado' : 'posts encontrados'}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredPosts.slice(1).map(post => (
                <article key={post.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(post.date)}
                      </div>
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {post.author}
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-bold text-ejx-blue mb-3 hover:text-ejx-orange transition-colors cursor-pointer">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.slice(0, 2).map(tag => (
                        <span
                          key={tag}
                          className="bg-ejx-gray text-ejx-blue px-2 py-1 rounded-full text-xs"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                    
                    <button className="text-ejx-orange hover:text-orange-600 font-semibold inline-flex items-center transition-colors">
                      Ler Mais
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </button>
                  </div>
                </article>
              ))}
            </div>

            {filteredPosts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">
                  Nenhum post encontrado para os critérios selecionados.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('todos')
                    setSearchTerm('')
                  }}
                  className="mt-4 text-ejx-orange hover:text-orange-600 font-semibold"
                >
                  Limpar Filtros
                </button>
              </div>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-20 bg-ejx-blue text-white rounded-lg p-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Precisa de Ajuda Profissional?
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Nossa equipe está pronta para resolver qualquer problema técnico
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/orcamento"
              className="bg-ejx-orange hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Solicitar Orçamento
            </Link>
            <Link
              to="/contato"
              className="border-2 border-white hover:bg-white hover:text-ejx-blue text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Falar Conosco
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Blog