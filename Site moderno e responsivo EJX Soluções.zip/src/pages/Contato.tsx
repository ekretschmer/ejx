import React, { useState } from 'react'
import {Phone, Mail, MapPin, Clock, MessageCircle, Send, Facebook, Instagram} from 'lucide-react'
import toast from 'react-hot-toast'

const Contato = () => {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: '',
    assunto: '',
    mensagem: ''
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.nome || !formData.email || !formData.mensagem) {
      toast.error('Preencha todos os campos obrigatórios')
      return
    }

    toast.success('Mensagem enviada com sucesso! Responderemos em breve.')
    
    setFormData({
      nome: '',
      email: '',
      telefone: '',
      assunto: '',
      mensagem: ''
    })
  }

  const contactInfo = [
    {
      icon: <Phone className="h-6 w-6 text-ejx-orange" />,
      title: "Telefone",
      content: "(11) 99999-9999",
      action: "tel:+5511999999999"
    },
    {
      icon: <MessageCircle className="h-6 w-6 text-ejx-orange" />,
      title: "WhatsApp",
      content: "(11) 99999-9999",
      action: "https://wa.me/5511999999999"
    },
    {
      icon: <Mail className="h-6 w-6 text-ejx-orange" />,
      title: "E-mail",
      content: "contato@ejxsolucoes.com.br",
      action: "mailto:contato@ejxsolucoes.com.br"
    },
    {
      icon: <MapPin className="h-6 w-6 text-ejx-orange" />,
      title: "Localização",
      content: "São Paulo - SP",
      action: "#"
    }
  ]

  const workingHours = [
    { day: "Segunda a Sexta", hours: "8h às 18h" },
    { day: "Sábado", hours: "8h às 12h" },
    { day: "Domingo", hours: "Apenas emergências" }
  ]

  return (
    <div>
      {/* Header */}
      <section className="bg-ejx-blue text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Entre em Contato
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
              Estamos prontos para atender você. Escolha a forma de contato que preferir
            </p>
          </div>
        </div>
      </section>

      {/* Informações de Contato */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactInfo.map((info, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg text-center hover:shadow-xl transition-shadow">
                <div className="flex justify-center mb-4">
                  {info.icon}
                </div>
                <h3 className="text-lg font-bold text-ejx-blue mb-2">{info.title}</h3>
                <a
                  href={info.action}
                  className="text-gray-600 hover:text-ejx-orange transition-colors"
                  target={info.action.startsWith('http') ? '_blank' : '_self'}
                  rel={info.action.startsWith('http') ? 'noopener noreferrer' : ''}
                >
                  {info.content}
                </a>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Formulário de Contato */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-ejx-blue mb-6">Envie uma Mensagem</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Nome *
                    </label>
                    <input
                      type="text"
                      name="nome"
                      value={formData.nome}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                      placeholder="Seu nome"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Telefone
                    </label>
                    <input
                      type="tel"
                      name="telefone"
                      value={formData.telefone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    Assunto
                  </label>
                  <select
                    name="assunto"
                    value={formData.assunto}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                  >
                    <option value="">Selecione um assunto</option>
                    <option value="orcamento">Solicitar Orçamento</option>
                    <option value="duvida">Dúvidas sobre Serviços</option>
                    <option value="suporte">Suporte Técnico</option>
                    <option value="parceria">Parceria</option>
                    <option value="outros">Outros</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    Mensagem *
                  </label>
                  <textarea
                    name="mensagem"
                    value={formData.mensagem}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    placeholder="Digite sua mensagem..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-ejx-orange hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                >
                  <Send className="h-5 w-5 mr-2" />
                  Enviar Mensagem
                </button>
              </form>
            </div>

            {/* Informações Adicionais */}
            <div className="space-y-8">
              {/* Horário de Funcionamento */}
              <div className="bg-ejx-gray rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <Clock className="h-6 w-6 text-ejx-orange mr-3" />
                  <h3 className="text-xl font-bold text-ejx-blue">Horário de Atendimento</h3>
                </div>
                <div className="space-y-3">
                  {workingHours.map((schedule, index) => (
                    <div key={index} className="flex justify-between">
                      <span className="text-gray-600">{schedule.day}:</span>
                      <span className="font-semibold text-ejx-blue">{schedule.hours}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Área de Atendimento */}
              <div className="bg-white rounded-lg shadow-lg p-6">
                <div className="flex items-center mb-4">
                  <MapPin className="h-6 w-6 text-ejx-orange mr-3" />
                  <h3 className="text-xl font-bold text-ejx-blue">Área de Atendimento</h3>
                </div>
                <p className="text-gray-600 mb-4">
                  Atendemos toda a região metropolitana de São Paulo, incluindo:
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li>• São Paulo (Capital)</li>
                  <li>• ABC Paulista</li>
                  <li>• Osasco e região</li>
                  <li>• Guarulhos</li>
                  <li>• Zona Norte, Sul, Leste e Oeste</li>
                </ul>
              </div>

              {/* Redes Sociais */}
              <div className="bg-ejx-blue text-white rounded-lg p-6">
                <h3 className="text-xl font-bold mb-4">Siga-nos nas Redes Sociais</h3>
                <div className="flex space-x-4">
                  <a
                    href="#"
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 p-3 rounded-lg transition-colors"
                  >
                    <Facebook className="h-6 w-6" />
                  </a>
                  <a
                    href="#"
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 p-3 rounded-lg transition-colors"
                  >
                    <Instagram className="h-6 w-6" />
                  </a>
                </div>
                <p className="text-gray-200 mt-4 text-sm">
                  Acompanhe nossas novidades, dicas e trabalhos realizados
                </p>
              </div>

              {/* Emergências */}
              <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                <h3 className="text-lg font-bold text-red-600 mb-2">Atendimento de Emergência</h3>
                <p className="text-red-700 text-sm mb-3">
                  Para emergências elétricas ou hidráulicas, entre em contato pelo WhatsApp 24h
                </p>
                <a
                  href="https://wa.me/5511999999999?text=Emergência!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  WhatsApp Emergência
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mapa */}
      <section className="py-20 bg-ejx-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-ejx-blue mb-4">Nossa Localização</h2>
            <p className="text-gray-600">Atendemos toda a região metropolitana de São Paulo</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="h-96 bg-gray-200 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-ejx-orange mx-auto mb-4" />
                <p className="text-gray-600">
                  Mapa interativo do Google Maps<br />
                  São Paulo e Região Metropolitana
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Contato