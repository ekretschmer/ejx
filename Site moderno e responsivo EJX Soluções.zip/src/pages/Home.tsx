import React from 'react'
import { Link } from 'react-router-dom'
import {ArrowRight, Home as HomeIcon, Zap, Wrench, Settings, Star, CheckCircle} from 'lucide-react'

const Home = () => {
  const services = [
    {
      icon: <Settings className="h-12 w-12 text-ejx-orange" />,
      title: "Automação Residencial",
      description: "Transforme sua casa em um ambiente inteligente e conectado."
    },
    {
      icon: <Zap className="h-12 w-12 text-ejx-orange" />,
      title: "Serviços Elétricos",
      description: "Instalações e manutenções elétricas com segurança e qualidade."
    },
    {
      icon: <Wrench className="h-12 w-12 text-ejx-orange" />,
      title: "Hidráulica e Reparos",
      description: "Soluções completas para problemas hidráulicos e pequenos reparos."
    }
  ]

  const testimonials = [
    {
      name: "Maria Silva",
      text: "Excelente atendimento! Resolveram meu problema elétrico rapidamente.",
      rating: 5
    },
    {
      name: "João Santos",
      text: "Automação residencial impecável. Recomendo a EJX Soluções!",
      rating: 5
    },
    {
      name: "Ana Costa",
      text: "Profissionais competentes e preço justo. Muito satisfeita!",
      rating: 5
    }
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-ejx-blue to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                EJX Soluções
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-gray-200">
                Tecnologia e cuidado para sua casa ou empresa
              </p>
              <p className="text-lg mb-8 text-gray-300">
                A empresa que resolve os detalhes que incomodam no dia a dia
              </p>
              <Link
                to="/orcamento"
                className="inline-flex items-center bg-ejx-orange hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
              >
                Solicitar Orçamento Agora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
            <div className="hidden lg:block">
              <img
                src="https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg"
                alt="Técnico trabalhando"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Serviços em Destaque */}
      <section className="py-20 bg-ejx-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              Nossos Principais Serviços
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Oferecemos soluções completas para sua residência ou empresa
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-center">
                  <div className="flex justify-center mb-4">
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-bold text-ejx-blue mb-4">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <Link
                    to="/servicos"
                    className="inline-flex items-center text-ejx-orange hover:text-orange-600 font-semibold"
                  >
                    Saiba Mais
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Por que escolher a EJX */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-6">
                Por que escolher a EJX Soluções?
              </h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-ejx-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-ejx-blue">Experiência Comprovada</h3>
                    <p className="text-gray-600">Anos de experiência em automação e manutenção</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-ejx-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-ejx-blue">Atendimento Personalizado</h3>
                    <p className="text-gray-600">Cada projeto é único e merece atenção especial</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-ejx-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-ejx-blue">Garantia de Qualidade</h3>
                    <p className="text-gray-600">Todos os serviços com garantia e suporte</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-ejx-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-ejx-blue">Preços Justos</h3>
                    <p className="text-gray-600">Orçamentos transparentes e competitivos</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg"
                alt="Equipe EJX Soluções"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-20 bg-ejx-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              O que nossos clientes dizem
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">"{testimonial.text}"</p>
                <p className="font-semibold text-ejx-blue">- {testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-ejx-blue text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Pronto para transformar sua casa ou empresa?
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Entre em contato conosco e solicite seu orçamento gratuito
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/orcamento"
              className="bg-ejx-orange hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Solicitar Orçamento
            </Link>
            <Link
              to="/contato"
              className="border-2 border-white hover:bg-white hover:text-ejx-blue text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Falar Conosco
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home