import React, { useState } from 'react'
import {ShoppingCart, Search, Filter, Plus, Minus, Truck, CreditCard} from 'lucide-react'
import toast from 'react-hot-toast'

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
  description: string
  inStock: boolean
}

interface CartItem extends Product {
  quantity: number
}

const Loja = () => {
  const [selectedCategory, setSelectedCategory] = useState('todos')
  const [searchTerm, setSearchTerm] = useState('')
  const [cart, setCart] = useState<CartItem[]>([])
  const [showCart, setShowCart] = useState(false)
  const [cep, setCep] = useState('')
  const [shippingCost, setShippingCost] = useState(0)

  const products: Product[] = [
    {
      id: 1,
      name: "Kit Automação Iluminação",
      price: 299.90,
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
      category: "automacao",
      description: "Kit completo para automação de iluminação residencial",
      inStock: true
    },
    {
      id: 2,
      name: "Interruptor Inteligente",
      price: 89.90,
      image: "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
      category: "automacao",
      description: "Interruptor WiFi compatível com Alexa e Google Home",
      inStock: true
    },
    {
      id: 3,
      name: "Sensor de Movimento",
      price: 45.90,
      image: "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
      category: "automacao",
      description: "Sensor de movimento para automação residencial",
      inStock: true
    },
    {
      id: 4,
      name: "Disjuntor 20A",
      price: 12.90,
      image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
      category: "eletrica",
      description: "Disjuntor monopolar 20A para quadro elétrico",
      inStock: true
    },
    {
      id: 5,
      name: "Fita LED 5m",
      price: 39.90,
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
      category: "eletrica",
      description: "Fita LED branca fria 5 metros com fonte",
      inStock: true
    },
    {
      id: 6,
      name: "Torneira Automática",
      price: 189.90,
      image: "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
      category: "hidraulica",
      description: "Torneira com sensor automático para banheiro",
      inStock: true
    },
    {
      id: 7,
      name: "Válvula Solenoide",
      price: 67.90,
      image: "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
      category: "hidraulica",
      description: "Válvula solenoide para controle de água",
      inStock: false
    },
    {
      id: 8,
      name: "Kit Ferramentas Básico",
      price: 149.90,
      image: "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
      category: "ferramentas",
      description: "Kit com ferramentas básicas para reparos",
      inStock: true
    }
  ]

  const categories = [
    { id: 'todos', name: 'Todos os Produtos' },
    { id: 'automacao', name: 'Automação' },
    { id: 'eletrica', name: 'Elétrica' },
    { id: 'hidraulica', name: 'Hidráulica' },
    { id: 'ferramentas', name: 'Ferramentas' }
  ]

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'todos' || product.category === selectedCategory
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const addToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id)
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      } else {
        return [...prevCart, { ...product, quantity: 1 }]
      }
    })
    toast.success('Produto adicionado ao carrinho!')
  }

  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId))
    toast.success('Produto removido do carrinho!')
  }

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity === 0) {
      removeFromCart(productId)
      return
    }
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === productId
          ? { ...item, quantity: newQuantity }
          : item
      )
    )
  }

  const calculateShipping = () => {
    if (cep.length === 8) {
      // Simulação de cálculo de frete
      const cost = Math.random() * 20 + 10
      setShippingCost(Number(cost.toFixed(2)))
      toast.success('Frete calculado com sucesso!')
    } else {
      toast.error('CEP inválido')
    }
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0)
  }

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-ejx-blue mb-4">Loja EJX Soluções</h1>
            <p className="text-gray-600">Peças e acessórios para automação e manutenção</p>
          </div>
          <button
            onClick={() => setShowCart(true)}
            className="relative bg-ejx-orange hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center"
          >
            <ShoppingCart className="h-5 w-5 mr-2" />
            Carrinho ({getTotalItems()})
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">
                {getTotalItems()}
              </span>
            )}
          </button>
        </div>

        {/* Filtros */}
        <div className="bg-ejx-gray rounded-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-ejx-blue mb-2">Buscar produtos</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Digite o nome do produto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-ejx-blue mb-2">Categoria</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Produtos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-bold text-ejx-blue mb-2">{product.name}</h3>
                <p className="text-gray-600 text-sm mb-3">{product.description}</p>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-2xl font-bold text-ejx-orange">
                    R$ {product.price.toFixed(2)}
                  </span>
                  <span className={`text-sm px-2 py-1 rounded ${product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {product.inStock ? 'Em estoque' : 'Fora de estoque'}
                  </span>
                </div>
                <button
                  onClick={() => addToCart(product)}
                  disabled={!product.inStock}
                  className={`w-full py-2 rounded-lg font-semibold transition-colors ${
                    product.inStock
                      ? 'bg-ejx-blue hover:bg-blue-800 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {product.inStock ? 'Adicionar ao Carrinho' : 'Indisponível'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Modal do Carrinho */}
        {showCart && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-ejx-blue">Carrinho de Compras</h2>
                  <button
                    onClick={() => setShowCart(false)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ✕
                  </button>
                </div>

                {cart.length === 0 ? (
                  <p className="text-center text-gray-500 py-8">Seu carrinho está vazio</p>
                ) : (
                  <>
                    {/* Itens do Carrinho */}
                    <div className="space-y-4 mb-6">
                      {cart.map(item => (
                        <div key={item.id} className="flex items-center space-x-4 border-b pb-4">
                          <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                          <div className="flex-1">
                            <h3 className="font-semibold text-ejx-blue">{item.name}</h3>
                            <p className="text-ejx-orange font-bold">R$ {item.price.toFixed(2)}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="bg-gray-200 hover:bg-gray-300 p-1 rounded"
                            >
                              <Minus className="h-4 w-4" />
                            </button>
                            <span className="w-8 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="bg-gray-200 hover:bg-gray-300 p-1 rounded"
                            >
                              <Plus className="h-4 w-4" />
                            </button>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            Remover
                          </button>
                        </div>
                      ))}
                    </div>

                    {/* Cálculo de Frete */}
                    <div className="border-t pt-4 mb-6">
                      <h3 className="font-semibold text-ejx-blue mb-3">Calcular Frete</h3>
                      <div className="flex space-x-2">
                        <input
                          type="text"
                          placeholder="Digite seu CEP"
                          value={cep}
                          onChange={(e) => setCep(e.target.value.replace(/\D/g, '').slice(0, 8))}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                        />
                        <button
                          onClick={calculateShipping}
                          className="bg-ejx-blue hover:bg-blue-800 text-white px-4 py-2 rounded-lg flex items-center"
                        >
                          <Truck className="h-4 w-4 mr-2" />
                          Calcular
                        </button>
                      </div>
                      {shippingCost > 0 && (
                        <p className="text-green-600 mt-2">Frete: R$ {shippingCost.toFixed(2)}</p>
                      )}
                    </div>

                    {/* Total */}
                    <div className="border-t pt-4">
                      <div className="flex justify-between items-center mb-2">
                        <span>Subtotal:</span>
                        <span>R$ {getTotalPrice().toFixed(2)}</span>
                      </div>
                      {shippingCost > 0 && (
                        <div className="flex justify-between items-center mb-2">
                          <span>Frete:</span>
                          <span>R$ {shippingCost.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center text-xl font-bold text-ejx-blue">
                        <span>Total:</span>
                        <span>R$ {(getTotalPrice() + shippingCost).toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Botões de Ação */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6">
                      <button className="bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center">
                        <CreditCard className="h-4 w-4 mr-2" />
                        PIX
                      </button>
                      <button className="bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Cartão
                      </button>
                      <button className="bg-gray-600 hover:bg-gray-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Boleto
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Loja