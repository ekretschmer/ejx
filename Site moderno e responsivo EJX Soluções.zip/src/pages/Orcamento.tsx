import React, { useState } from 'react'
import {Send, Upload, MessageCircle, Mail, Phone, MapPin} from 'lucide-react'
import toast from 'react-hot-toast'

const Orcamento = () => {
  const [formData, setFormData] = useState({
    nome: '',
    telefone: '',
    email: '',
    endereco: '',
    servico: '',
    descricao: '',
    urgencia: 'normal'
  })
  
  const [files, setFiles] = useState<File[]>([])

  const services = [
    'Automação Residencial',
    'Serviços Elétricos',
    'Serviços Hidráulicos',
    'Pequenos Reparos',
    'Gesso e Acabamentos',
    'Pisos e Revestimentos',
    'Outros'
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files)
      setFiles(prev => [...prev, ...selectedFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validação básica
    if (!formData.nome || !formData.telefone || !formData.servico) {
      toast.error('Preencha todos os campos obrigatórios')
      return
    }

    // Simular envio
    toast.success('Orçamento enviado com sucesso! Entraremos em contato em breve.')
    
    // Reset form
    setFormData({
      nome: '',
      telefone: '',
      email: '',
      endereco: '',
      servico: '',
      descricao: '',
      urgencia: 'normal'
    })
    setFiles([])
  }

  const sendToWhatsApp = () => {
    const message = `Olá! Gostaria de solicitar um orçamento:

Nome: ${formData.nome}
Telefone: ${formData.telefone}
Serviço: ${formData.servico}
Descrição: ${formData.descricao}
Endereço: ${formData.endereco}
Urgência: ${formData.urgencia}`

    const phoneNumber = "5511999999999"
    const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`
    window.open(url, '_blank')
  }

  return (
    <div className="py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-ejx-blue mb-6">
            Solicite seu Orçamento
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Preencha o formulário abaixo e receba um orçamento personalizado para suas necessidades
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-ejx-blue mb-6">Dados do Orçamento</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Dados Pessoais */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      name="nome"
                      value={formData.nome}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                      placeholder="Seu nome completo"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Telefone *
                    </label>
                    <input
                      type="tel"
                      name="telefone"
                      value={formData.telefone}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    E-mail
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    Endereço Completo
                  </label>
                  <input
                    type="text"
                    name="endereco"
                    value={formData.endereco}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    placeholder="Rua, número, bairro, cidade"
                  />
                </div>

                {/* Serviço */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Tipo de Serviço *
                    </label>
                    <select
                      name="servico"
                      value={formData.servico}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    >
                      <option value="">Selecione um serviço</option>
                      {services.map(service => (
                        <option key={service} value={service}>{service}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ejx-blue mb-2">
                      Urgência
                    </label>
                    <select
                      name="urgencia"
                      value={formData.urgencia}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    >
                      <option value="baixa">Baixa - Posso aguardar</option>
                      <option value="normal">Normal - Alguns dias</option>
                      <option value="alta">Alta - Preciso urgente</option>
                      <option value="emergencia">Emergência - Hoje</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    Descrição do Problema/Serviço
                  </label>
                  <textarea
                    name="descricao"
                    value={formData.descricao}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-ejx-orange focus:border-transparent"
                    placeholder="Descreva detalhadamente o que precisa ser feito..."
                  />
                </div>

                {/* Upload de Arquivos */}
                <div>
                  <label className="block text-sm font-medium text-ejx-blue mb-2">
                    Fotos ou Vídeos (Opcional)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-4">
                      Arraste arquivos aqui ou clique para selecionar
                    </p>
                    <input
                      type="file"
                      multiple
                      accept="image/*,video/*"
                      onChange={handleFileChange}
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="bg-ejx-blue hover:bg-blue-800 text-white px-4 py-2 rounded-lg cursor-pointer transition-colors"
                    >
                      Selecionar Arquivos
                    </label>
                  </div>
                  
                  {files.length > 0 && (
                    <div className="mt-4">
                      <p className="text-sm font-medium text-ejx-blue mb-2">Arquivos selecionados:</p>
                      <div className="space-y-2">
                        {files.map((file, index) => (
                          <div key={index} className="flex items-center justify-between bg-gray-100 p-2 rounded">
                            <span className="text-sm text-gray-600">{file.name}</span>
                            <button
                              type="button"
                              onClick={() => removeFile(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              Remover
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Botões */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <button
                    type="submit"
                    className="flex-1 bg-ejx-orange hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                  >
                    <Send className="h-5 w-5 mr-2" />
                    Enviar Orçamento
                  </button>
                  <button
                    type="button"
                    onClick={sendToWhatsApp}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors flex items-center justify-center"
                  >
                    <MessageCircle className="h-5 w-5 mr-2" />
                    Enviar via WhatsApp
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Informações de Contato */}
          <div className="space-y-6">
            <div className="bg-ejx-blue text-white rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4">Outras formas de contato</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-ejx-orange" />
                  <div>
                    <p className="font-semibold">Telefone</p>
                    <p className="text-gray-200">(11) 99999-9999</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-ejx-orange" />
                  <div>
                    <p className="font-semibold">E-mail</p>
                    <p className="text-gray-200">contato@ejxsolucoes.com.br</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-ejx-orange" />
                  <div>
                    <p className="font-semibold">Atendimento</p>
                    <p className="text-gray-200">São Paulo e região metropolitana</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-ejx-gray rounded-lg p-6">
              <h3 className="text-lg font-bold text-ejx-blue mb-4">Horário de Atendimento</h3>
              <div className="space-y-2 text-gray-600">
                <p><strong>Segunda a Sexta:</strong> 8h às 18h</p>
                <p><strong>Sábado:</strong> 8h às 12h</p>
                <p><strong>Domingo:</strong> Apenas emergências</p>
              </div>
            </div>

            <div className="bg-orange-50 border border-ejx-orange rounded-lg p-6">
              <h3 className="text-lg font-bold text-ejx-orange mb-2">Orçamento Gratuito</h3>
              <p className="text-gray-600 text-sm">
                Todos os nossos orçamentos são gratuitos e sem compromisso. 
                Responderemos em até 24 horas úteis.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Orcamento