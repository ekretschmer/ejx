import React from 'react'
import {Users, Target, Award, Clock, CheckCircle, Star} from 'lucide-react'

const QuemSomos = () => {
  const values = [
    {
      icon: <Target className="h-12 w-12 text-ejx-orange" />,
      title: "Missão",
      description: "Simplificar a vida dos nossos clientes através de soluções tecnológicas e serviços de qualidade, resolvendo os detalhes que incomodam no dia a dia."
    },
    {
      icon: <Users className="h-12 w-12 text-ejx-orange" />,
      title: "Visão",
      description: "Ser reconhecida como a empresa de referência em automação residencial e soluções técnicas na região metropolitana de São Paulo."
    },
    {
      icon: <Award className="h-12 w-12 text-ejx-orange" />,
      title: "Valores",
      description: "Qualidade, confiança, inovação e compromisso com a satisfação do cliente são os pilares que guiam todos os nossos serviços."
    }
  ]

  const team = [
    {
      name: "Eduardo Silva",
      role: "Fundador e Diretor Técnico",
      image: "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
      description: "15 anos de experiência em automação e sistemas elétricos"
    },
    {
      name: "João Santos",
      role: "Especialista em Automação",
      image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
      description: "Certificado em sistemas de automação residencial"
    },
    {
      name: "Carlos Oliveira",
      role: "Técnico em Elétrica",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
      description: "Especialista em instalações elétricas e manutenção"
    },
    {
      name: "Ana Costa",
      role: "Atendimento ao Cliente",
      image: "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
      description: "Responsável pelo relacionamento e suporte aos clientes"
    }
  ]

  const achievements = [
    { number: "500+", label: "Projetos Realizados" },
    { number: "5", label: "Anos de Experiência" },
    { number: "98%", label: "Clientes Satisfeitos" },
    { number: "24h", label: "Suporte Técnico" }
  ]

  const workGallery = [
    "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
    "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
    "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
    "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
    "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
    "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg"
  ]

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-ejx-blue to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Sobre a EJX Soluções
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
              A empresa que resolve os detalhes que incomodam no dia a dia, 
              com tecnologia, cuidado e compromisso com a qualidade.
            </p>
          </div>
        </div>
      </section>

      {/* Nossa História */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-6">
                Nossa História
              </h2>
              <div className="space-y-4 text-gray-600 text-lg">
                <p>
                  A EJX Soluções nasceu da necessidade de oferecer serviços técnicos 
                  de qualidade com um atendimento diferenciado. Fundada em 2019, 
                  começamos como uma pequena empresa familiar focada em resolver 
                  os pequenos problemas que incomodam no dia a dia das pessoas.
                </p>
                <p>
                  Com o tempo, expandimos nossos serviços para incluir automação 
                  residencial, sempre mantendo nosso compromisso com a qualidade 
                  e a satisfação do cliente. Hoje, somos reconhecidos na região 
                  metropolitana de São Paulo pela excelência em nossos serviços.
                </p>
                <p>
                  Nossa equipe é formada por profissionais qualificados e 
                  apaixonados pelo que fazem, sempre em busca de soluções 
                  inovadoras e eficientes para nossos clientes.
                </p>
              </div>
            </div>
            <div>
              <img
                src="https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg"
                alt="Equipe EJX Soluções trabalhando"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Missão, Visão e Valores */}
      <section className="py-20 bg-ejx-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              Nossos Princípios
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Os valores que nos guiam em cada projeto e relacionamento com nossos clientes
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-lg text-center hover:shadow-xl transition-shadow">
                <div className="flex justify-center mb-6">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-ejx-blue mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Números */}
      <section className="py-20 bg-ejx-blue text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Nossos Números
            </h2>
            <p className="text-xl text-gray-200">
              Resultados que comprovam nossa dedicação e qualidade
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-ejx-orange mb-2">
                  {achievement.number}
                </div>
                <p className="text-gray-200">{achievement.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Nossa Equipe */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              Nossa Equipe
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Profissionais qualificados e comprometidos com a excelência
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-ejx-blue mb-2">{member.name}</h3>
                  <p className="text-ejx-orange font-semibold mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Diferenciais */}
      <section className="py-20 bg-ejx-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              Por que escolher a EJX?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <CheckCircle className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Atendimento Personalizado</h3>
              <p className="text-gray-600">Cada cliente é único e merece atenção especial</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Clock className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Pontualidade</h3>
              <p className="text-gray-600">Cumprimento rigoroso de prazos e horários</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Award className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Garantia de Qualidade</h3>
              <p className="text-gray-600">Todos os serviços com garantia e suporte</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Star className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Materiais de Primeira</h3>
              <p className="text-gray-600">Utilizamos apenas materiais de qualidade</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <Users className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Equipe Qualificada</h3>
              <p className="text-gray-600">Profissionais certificados e experientes</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <CheckCircle className="h-12 w-12 text-ejx-orange mb-4" />
              <h3 className="text-lg font-bold text-ejx-blue mb-3">Preços Justos</h3>
              <p className="text-gray-600">Orçamentos transparentes e competitivos</p>
            </div>
          </div>
        </div>
      </section>

      {/* Galeria de Trabalhos */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-ejx-blue mb-4">
              Nossos Trabalhos
            </h2>
            <p className="text-lg text-gray-600">
              Alguns dos projetos que realizamos com orgulho
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {workGallery.map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`Trabalho ${index + 1}`}
                className="rounded-lg shadow-lg hover:shadow-xl transition-shadow w-full h-48 object-cover"
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-ejx-blue text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Faça parte da nossa história
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Entre em contato e descubra como podemos ajudar você
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/orcamento"
              className="bg-ejx-orange hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Solicitar Orçamento
            </a>
            <a
              href="/contato"
              className="border-2 border-white hover:bg-white hover:text-ejx-blue text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Falar Conosco
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

export default QuemSomos