import React from 'react'
import { useParams, Link } from 'react-router-dom'
import {ArrowLeft, CheckCircle, Clock, Users, Award} from 'lucide-react'

const ServicoDetalhes = () => {
  const { slug } = useParams()

  const serviceDetails = {
    'automacao-residencial': {
      title: "Automação Residencial",
      subtitle: "Transforme sua casa em um ambiente inteligente",
      description: "Nossa automação residencial oferece controle total sobre os sistemas da sua casa através de dispositivos móveis ou comandos de voz. Integração com as principais plataformas do mercado.",
      image: "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
      features: [
        "Controle de iluminação inteligente",
        "Sistemas de segurança integrados",
        "Climatização automatizada",
        "Integração com Alexa e Google Home",
        "Controle de persianas e cortinas",
        "Monitoramento remoto"
      ],
      process: [
        "Análise das necessidades do cliente",
        "Projeto personalizado",
        "Instalação dos equipamentos",
        "Configuração e testes",
        "Treinamento do usuário"
      ],
      gallery: [
        "https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg",
        "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
        "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg"
      ]
    },
    'eletrica': {
      title: "Serviços Elétricos",
      subtitle: "Instalações e manutenções elétricas seguras",
      description: "Realizamos todos os tipos de serviços elétricos com total segurança e qualidade. Nossa equipe é certificada e utiliza apenas materiais de primeira linha.",
      image: "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
      features: [
        "Instalações elétricas residenciais",
        "Quadros elétricos e disjuntores",
        "Iluminação LED eficiente",
        "Manutenção preventiva",
        "Reparos de emergência",
        "Certificação INMETRO"
      ],
      process: [
        "Diagnóstico da situação",
        "Orçamento detalhado",
        "Execução do serviço",
        "Testes de segurança",
        "Entrega com garantia"
      ],
      gallery: [
        "https://images.pexels.com/photos/257736/pexels-photo-257736.jpeg",
        "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
        "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg"
      ]
    },
    'hidraulica': {
      title: "Serviços Hidráulicos",
      subtitle: "Soluções completas em hidráulica",
      description: "Desde pequenos vazamentos até instalações completas, nossa equipe resolve todos os problemas hidráulicos com agilidade e eficiência.",
      image: "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
      features: [
        "Reparos de vazamentos",
        "Instalação de tubulações",
        "Desentupimentos",
        "Manutenção de torneiras",
        "Instalação de aquecedores",
        "Sistemas de irrigação"
      ],
      process: [
        "Identificação do problema",
        "Orçamento transparente",
        "Execução rápida",
        "Teste de funcionamento",
        "Limpeza do local"
      ],
      gallery: [
        "https://images.pexels.com/photos/1123262/pexels-photo-1123262.jpeg",
        "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
        "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg"
      ]
    },
    'pequenos-reparos': {
      title: "Pequenos Reparos",
      subtitle: "Resolvemos os detalhes que incomodam",
      description: "Aqueles pequenos problemas do dia a dia que precisam de atenção profissional. Nossa equipe resolve com rapidez e preço justo.",
      image: "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
      features: [
        "Furos em paredes e azulejos",
        "Troca de fechaduras",
        "Montagem de móveis",
        "Instalação de suportes",
        "Reparos em portas",
        "Pequenos consertos diversos"
      ],
      process: [
        "Avaliação do reparo",
        "Orçamento imediato",
        "Execução no mesmo dia",
        "Verificação final",
        "Satisfação garantida"
      ],
      gallery: [
        "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg",
        "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg",
        "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg"
      ]
    },
    'gesso': {
      title: "Gesso e Acabamentos",
      subtitle: "Beleza e funcionalidade para seus ambientes",
      description: "Trabalhos em gesso que transformam ambientes, oferecendo beleza, funcionalidade e acabamento perfeito para sua casa ou empresa.",
      image: "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
      features: [
        "Forros de gesso tradicionais",
        "Divisórias em drywall",
        "Sancas e molduras",
        "Acabamentos decorativos",
        "Isolamento acústico",
        "Pinturas especiais"
      ],
      process: [
        "Medição e projeto",
        "Escolha dos materiais",
        "Execução da estrutura",
        "Acabamento fino",
        "Pintura final"
      ],
      gallery: [
        "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
        "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
        "https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg"
      ]
    },
    'pisos': {
      title: "Pisos e Revestimentos",
      subtitle: "Renovação com qualidade e durabilidade",
      description: "Instalação e manutenção de pisos diversos, renovando seus ambientes com materiais de qualidade e acabamento profissional.",
      image: "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
      features: [
        "Pisos laminados e vinílicos",
        "Cerâmicas e porcelanatos",
        "Pisos de madeira",
        "Reparos e restauração",
        "Rodapés e acabamentos",
        "Impermeabilização"
      ],
      process: [
        "Análise do ambiente",
        "Escolha do material",
        "Preparação do substrato",
        "Instalação profissional",
        "Acabamentos finais"
      ],
      gallery: [
        "https://images.pexels.com/photos/1571463/pexels-photo-1571463.jpeg",
        "https://images.pexels.com/photos/1669799/pexels-photo-1669799.jpeg",
        "https://images.pexels.com/photos/1249611/pexels-photo-1249611.jpeg"
      ]
    }
  }

  const service = serviceDetails[slug as keyof typeof serviceDetails]

  if (!service) {
    return (
      <div className="py-20 text-center">
        <h1 className="text-2xl font-bold text-ejx-blue">Serviço não encontrado</h1>
        <Link to="/servicos" className="text-ejx-orange hover:underline mt-4 inline-block">
          Voltar aos serviços
        </Link>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div className="bg-ejx-blue text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link to="/servicos" className="inline-flex items-center text-gray-300 hover:text-white mb-6">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Voltar aos Serviços
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{service.title}</h1>
          <p className="text-xl text-gray-200">{service.subtitle}</p>
        </div>
      </div>

      {/* Content */}
      <div className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            <div>
              <img
                src={service.image}
                alt={service.title}
                className="rounded-lg shadow-lg w-full h-96 object-cover"
              />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-ejx-blue mb-6">Sobre este serviço</h2>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">{service.description}</p>
              
              <h3 className="text-xl font-bold text-ejx-blue mb-4">O que está incluso:</h3>
              <ul className="space-y-3">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-ejx-orange mr-3" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Processo */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-ejx-blue mb-8 text-center">Nosso Processo</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              {service.process.map((step, index) => (
                <div key={index} className="text-center">
                  <div className="bg-ejx-orange text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                    {index + 1}
                  </div>
                  <p className="text-gray-600 font-medium">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Galeria */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-ejx-blue mb-8 text-center">Galeria</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {service.gallery.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${service.title} ${index + 1}`}
                  className="rounded-lg shadow-lg w-full h-64 object-cover hover:shadow-xl transition-shadow"
                />
              ))}
            </div>
          </div>

          {/* Diferenciais */}
          <div className="bg-ejx-gray rounded-lg p-8 mb-16">
            <h2 className="text-3xl font-bold text-ejx-blue mb-8 text-center">Por que escolher a EJX?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <Clock className="h-12 w-12 text-ejx-orange mx-auto mb-4" />
                <h3 className="font-bold text-ejx-blue mb-2">Agilidade</h3>
                <p className="text-gray-600">Atendimento rápido e execução no prazo</p>
              </div>
              <div className="text-center">
                <Users className="h-12 w-12 text-ejx-orange mx-auto mb-4" />
                <h3 className="font-bold text-ejx-blue mb-2">Experiência</h3>
                <p className="text-gray-600">Equipe qualificada e experiente</p>
              </div>
              <div className="text-center">
                <Award className="h-12 w-12 text-ejx-orange mx-auto mb-4" />
                <h3 className="font-bold text-ejx-blue mb-2">Qualidade</h3>
                <p className="text-gray-600">Materiais de primeira e garantia</p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="bg-ejx-blue text-white rounded-lg p-8 text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Interessado neste serviço?
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Solicite seu orçamento gratuito e sem compromisso
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/orcamento"
                className="bg-ejx-orange hover:bg-orange-600 text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
              >
                Solicitar Orçamento
              </Link>
              <Link
                to="/contato"
                className="border-2 border-white hover:bg-white hover:text-ejx-blue text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
              >
                Falar Conosco
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ServicoDetalhes